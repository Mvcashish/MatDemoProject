import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class DataService {
baseUrl = 'https://s3.eu-west-2.amazonaws.com/interview-question-data/metoffice';

constructor(private httpClient: HttpClient) {}

get_Data(metric: string, location: string) {
    return this.httpClient.get(this.baseUrl + '/' + metric + '-' + location + '.json');
}
}

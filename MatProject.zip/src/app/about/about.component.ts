import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DataService } from './../data.service';
import { Component, OnInit } from '@angular/core';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';
import { FormControl } from '@angular/forms';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { Observable } from 'rxjs';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import {MatDatepicker} from '@angular/material/datepicker';
import * as _moment from 'moment';
// tslint:disable-next-line:no-duplicate-imports


const moment =  _moment;
export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/YYYY',
  },
  display: {
    dateInput: 'MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css'],
  providers: [
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ],

})
export class AboutComponent implements OnInit {
  public metrics: any[];
  public locations: any[];
  events: string[] = [];
  private data  = [];
  public summaries: any[];
  maxDate = new FormControl(moment());
  minDate =  new FormControl(moment());
  minDateMonth = '1';
  maxDateMonth = '12';
  minDateYear = '2019';
  maxDateYear = '2019';

  public barChartOptions: ChartOptions = {
    responsive: true,
  };
  public serviceData: Observable<any[]>;
  public barChartLabels: Label[];
  public barChartType: ChartType = 'bar';
  public barChartLegend = true;
  public barChartPlugins = [];
  metric = 'Rainfall';
  location = 'England';
  public barChartData: ChartDataSets[] = [
    { data: [65, 59, 80, 81, 56, 55, 42, 65, 59, 80, 81, 56, 55], label: 'Weather Report'}
  ];

  constructor(private dataService: DataService) {

    this.metrics = ['Tmax', 'Tmin', 'Rainfall'];
    this.locations = ['UK', 'England', 'Scotland', 'Wales'];
    this.dataService.get_Data('Rainfall', 'England').subscribe((res: any[]) => {
      this.data = res;
      this.summaries = this.data;

      this.summaries = this.summaries.filter(m => m.year >= this.minDateYear && m.month >= this.minDateMonth);
      this.summaries = this.summaries.filter(m => m.year <= this.maxDateYear);
      console.log(this.summaries);
       var datas = this.transformdata(this.summaries);
      this.barChartLabels = datas.chartlabel;
     this.barChartData[0] = {data: datas.chartdata, label: 'Weather Report'};
    });
   }

  ngOnInit() {
  }

  chosenYearHandler(normalizedYear: _moment.Moment, mtype: string) {

    if (mtype === 'max') {
      const ctrlValue = this.maxDate.value;
      ctrlValue.year(normalizedYear.year());
      this.maxDate.setValue(ctrlValue);

    } else {
      const ctrlValue = this.minDate.value;
      ctrlValue.year(normalizedYear.year());
      this.minDate.setValue(ctrlValue);

    }
  }

  chosenMonthHandler(normalizedMonth: _moment.Moment, datepicker: MatDatepicker<_moment.Moment>, mtype: string) {
    if (mtype === 'max') {

        const ctrlValue = this.maxDate.value;
        ctrlValue.month(normalizedMonth.month());
        this.maxDate.setValue(ctrlValue);
        this.maxDateYear =  this.maxDate.value.format('YYYY');
        this.maxDateMonth =  this.maxDate.value.format('MM');
        this.filterData();
    } else {
        const ctrlValue = this.minDate.value;
        ctrlValue.month(normalizedMonth.month());
        this.minDate.setValue(ctrlValue);
        this.minDateYear =  this.minDate.value.format('YYYY');
        this.minDateMonth =  this.minDate.value.format('MM');
    }
    datepicker.close();
  }
  filterData() {
     this.dataService.get_Data(this.metric, this.location).subscribe((res: any[]) => {
      this.data = res;
      this.summaries = this.data;
      this.summaries = this.summaries.filter(m => m.year >= Number(this.minDateYear) && m.month >= Number(this.minDateMonth));
      this.summaries = this.summaries.filter(m => m.year <= Number(this.maxDateYear));
      var datas = this.transformdata(this.summaries);
      this.barChartLabels = datas.chartlabel;
     this.barChartData[0] = {data: datas.chartdata, label: 'Weather Report'};
    });
  }

  transformdata (data) {
      var chartlabel= [];
      var chartdata = [];
      data.forEach(item => {
       if (item.month === 1) {
        chartlabel.push(item.year + '-Jan');
       }
       if (item.month === 2) {
        chartlabel.push(item.year + '-Feb');
       }
       if (item.month === 3) {
        chartlabel.push(item.year + '-Mar');
       }
       if (item.month === 4) {
        chartlabel.push(item.year + '-Apr');
       }
       if (item.month === 5) {
        chartlabel.push(item.year + '-May');
       }
       if (item.month === 6) {
        chartlabel.push(item.year + '-Jun');
       }
       if (item.month === 7) {
        chartlabel.push(item.year + '-Jul');
       }
       if (item.month === 8) {
        chartlabel.push(item.year + '-Aug');
       }
       if (item.month === 9) {
        chartlabel.push(item.year + 'Sep');
       }
       if (item.month === 10) {
        chartlabel.push(item.year + '-Oct');
       }
       if (item.month === 11) {
        chartlabel.push(item.year + '-Nov');
       }
       if (item.month === 12) {
        chartlabel.push(item.year + '-Dec');
       }
       chartdata.push(item.value);
      });
      return  { chartlabel: chartlabel, chartdata: chartdata};
  }
}
